import time
import paho.mqtt.client as mqtt

student_name = "Jidugu Sai"
unique_id = "42130205"
topic = "home/sai-2025/sensor"

broker = "localhost"
client = mqtt.Client(student_name)
client.connect(broker)

while True:
    temperature = 25
    humidity = 60
    vibration = 1

    payload = f"""
    name:{student_name},
    reg:{unique_id},
    temp:{temperature},
    hum:{humidity},
    vibration:{vibration}
    """

    client.publish(topic, payload)
    print("Published:", payload)

    time.sleep(3)
