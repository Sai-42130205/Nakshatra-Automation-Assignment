# Nakshatra Automation – Home Assistant Assignment
Student Name: Jidugu Sai
Register Number: 42130205
MQTT Topic Used: home/sai-2025/sensor

## Tasks Completed
- Installed Home Assistant
- Installed Mosquitto MQTT Broker
- Python -> MQTT -> Home Assistant Integration
- Displayed sensors in HA Dashboard
- Recorded 2–4 minute demonstration video

## Extra Sensor Used
Vibration sensor (value = 1)

## Files Included
- mqtt_publish.py
- Summary PDF
- README.md
